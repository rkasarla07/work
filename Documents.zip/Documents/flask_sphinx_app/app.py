from flask import Flask, render_template, request, jsonify
import sphinxapi
import re

app = Flask(__name__)

def is_special(query):
    return bool(re.search(r'[!@#$%^&*()_+{}\[\]:;<>,.?~\\]', query))

def transform_query(query):
    if is_special(query):
        return f'"{query}"'
    else:
        return query

def search_in_sphinx(query):
    client = sphinxapi.SphinxClient()
    client.SetServer('localhost', 1222)
    results = client.Query(query, 'csv_index')

    response = {}
    if results and results['matches']:
        response["question"] = query
        response["answer"] = results['matches'][0]['attrs']['answer']
    else:
        response["question"] = query
        response["answer"] = "I am unable to find an appropriate response to your query at this moment. I will provide you a response within 24 hours."

    return response

@app.route('/', methods=['GET', 'POST'])
def index():
    response = ''
    if request.method == 'POST':
        query = request.form['query']
        transformed_query = transform_query(query)
        result = search_in_sphinx(transformed_query)
        response = result["answer"]
    return render_template('index.html', response=response)

@app.route('/search', methods=['POST'])
def search_api():
    query = request.json.get('question', '')
    transformed_query = transform_query(query)
    response = search_in_sphinx(transformed_query.replace('_', ' '))
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)

